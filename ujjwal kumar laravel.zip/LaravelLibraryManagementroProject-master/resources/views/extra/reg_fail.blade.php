@extends('layouts.app')
@section('root')
    <div class="container col fhw">
        <h1 class="text_center_flex">
            Registration is unsuccessful!
        </h1>
    </div>
@endsection