@extends('layouts.app')
@section('root')
    <div class="container col fhw">
        <h1 class="text_center_flex">
            Success!
        </h1>
    </div>
@endsection